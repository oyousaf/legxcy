import { MdBarChart } from "react-icons/md";
import { FaPlusCircle } from "react-icons/fa";
import { LuShoppingBasket } from "react-icons/lu";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

import AnalyticsTab from "../components/AnalyticsTab";
import CreateProductForm from "../components/CreateProductForm";
import ProductsList from "../components/ProductsList";
import { useProductStore } from "../stores/useProductStore";
import { useUserStore } from "../stores/useUserStore";

const tabs = [
  { id: "create", label: "Create Product", icon: FaPlusCircle },
  { id: "products", label: "Products", icon: LuShoppingBasket },
  { id: "analytics", label: "Analytics", icon: MdBarChart },
];

const skeletonClass = "animate-pulse bg-gray-700 rounded-lg h-20 mb-4 w-full";

const AdminPage = () => {
  const [activeTab, setActiveTab] = useState("create");
  const { fetchAllProducts } = useProductStore();
  const { user, profile, checkingAuth } = useUserStore();
  const navigate = useNavigate();

  useEffect(() => {
    fetchAllProducts();
  }, [fetchAllProducts]);

  useEffect(() => {
    if (!checkingAuth && (!user || profile?.role !== "admin")) {
      navigate("/", { replace: true });
    }
  }, [checkingAuth, user, profile, navigate]);

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="relative z-10 container mx-auto px-4 py-16">
        <motion.h1
          className="text-4xl font-bold mb-8 text-emerald-400 text-center"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          Admin Dashboard
        </motion.h1>

        <div className="flex justify-center mb-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center px-4 py-2 mx-2 rounded-md transition-colors duration-200 ${
                activeTab === tab.id
                  ? "bg-emerald-600 text-white"
                  : "bg-gray-700 text-gray-300 hover:bg-gray-600"
              }`}
              disabled={checkingAuth || !user || !profile}
            >
              <tab.icon className="mr-2 h-5 w-5" />
              {tab.label}
            </button>
          ))}
        </div>

        {checkingAuth || !user || !profile ? (
          <div>
            <div className={skeletonClass} />
            <div className={skeletonClass} />
            <div className={skeletonClass} />
          </div>
        ) : (
          <>
            {activeTab === "create" && <CreateProductForm />}
            {activeTab === "products" && <ProductsList />}
            {activeTab === "analytics" && <AnalyticsTab />}
          </>
        )}
      </div>
    </div>
  );
};

export default AdminPage;
